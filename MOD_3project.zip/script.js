// Assignment Code
var generateBtn = document.querySelector("#generate");

//These are the char the function will choose from

var passWord =  [
    
    upperCase = "ABCDEFGHIJKLMNOPQRSTUVWXYZ",

    lowerCase = "abcdefghijklmnopqrstuvwxyz",

    numbers = "1234567890",

    speChars = "!@#$%^&*()_+-/?",

]

// These are the prompts for password criteria
// This is the code that intializes the prompts when the generate button is clicked

function input () {

  var length = prompt("How many characters should your password have?");

  var upperCase = prompt("Should uppercase letters be included in your password?"); 

  var lowerCase = prompt("Should lowercase letters be included in your password?"); 

  var numbers = prompt("Should numbers be included in your password?"); 

  var speChars = prompt("Should special characters be included in your password?"); 

  // An array of user input sent to local storage for retrieval

}


// Write password to the #password input
function writePassword() {
  var password = generatePassword();
  var passwordText = document.querySelector("#password");

// This is the loop that will run until the specified number of chars are reached. 
    

  passwordText.value = password;

}


// Add event listener to generate button
generateBtn.addEventListener("click", input);
