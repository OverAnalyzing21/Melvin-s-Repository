// eventlisstner that listens for a user click from user
document.getElementById("startbtn")
        .addEventListener("click")

// array of 5 quiz ?s
var quizQuestions= [ 
    "Who invented JavaScript?",

    "What year was JavaScript created?",

    "JavaScript stores information in a ______.",

    "A ______ is a block of code giving to a machine to complete a specific task.",

    "JavaScript uses ______ to loop through a function a specific amount of times. ",
];


// also a function to start timer at the same time
// find code to create function to cycle through array

